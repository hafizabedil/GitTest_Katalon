import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.webui.contribution.WebUiDriverCleaner
import com.kms.katalon.core.mobile.contribution.MobileDriverCleaner
import com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner
import com.kms.katalon.core.windows.keyword.contribution.WindowsDriverCleaner
import com.kms.katalon.core.testng.keyword.internal.TestNGDriverCleaner


DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.windows.keyword.contribution.WindowsDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.testng.keyword.internal.TestNGDriverCleaner())


RunConfiguration.setExecutionSettingFile('C:\\Users\\Hafiz\\AppData\\Local\\Temp\\Katalon\\Test Cases\\TCManual - Project Incentive Request\\5_Cheker\\TCB.18.19.20_RoleChecker - PIR - Add employe\\20250414_170307\\execution.properties')

TestCaseMain.beforeStart()

        TestCaseMain.runTestCaseRawScript(
'''import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

not_run: WebUI.callTestCase(findTestCase('TCLogin Common/TCFlow_LoginValid - Checker'), [:], FailureHandling.STOP_ON_FAILURE)

not_run: if (true == findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Menu_Projects')) {
}

WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Menu_Projects'))

WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Menu_Project Incentive Request'))

WebUI.verifyElementText(findTestObject('Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/btn_Summary'), 
    'Summary')

WebUI.click(findTestObject('Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/btn_Summary'))

WebUI.comment('Btn Summary')

WebUI.verifyElementText(findTestObject('Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/btn_IP Distribution'), 
    'IP Distribution')

WebUI.click(findTestObject('Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/btn_IP Distribution'))

not_run: WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/button_Summary'))

not_run: WebUI.verifyElementPresent(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/button_IP Distribution'), 
    0)

not_run: WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/button_IP Distribution'))

WebUI.comment('Sheet Bonus Distribution')

not_run: WebUI.verifyElementText(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/button_Draft'), 
    'Draft')

WebUI.verifyElementPresent(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/button_Rp_p-ripple p-element p-button p-com_ccf36c'), 
    0)

WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/Input'))

WebUI.verifyElementPresent(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/span_Rp_p-button-icon ri-delete-bin-line ng_8b6a0c'), 
    0)

WebUI.comment('Sheet Bonus Distribution - Sales')

WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Employe Sales1'))

WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Select_AAD ALIYUDIN'))

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/select_PilihManagerAdmin SalesStaff SalesPre-Sales'), 
    'Manager', true)

WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/DropD_Nama Pegawai Sales1'))

WebUI.setText(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Select_Nama Pegawai Sales ke1'), 
    '22')

WebUI.click(findTestObject('Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/Add Member-sales'), 
    FailureHandling.CONTINUE_ON_FAILURE)

WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/td__1'))

WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/svg_Rp_p-dropdown-trigger-icon p-icon'))

WebUI.comment('Sheet Bonus Distribution - Technician')

WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/span_ACHMADI MAULIA NUGRAHA'))

WebUI.setText(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/input_-_form-control form-control-sm ng-unt_75bb69'), 
    '11')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/select_PilihProject ManagerSolution Archite_53388f'), 
    'Project Manager', true)

WebUI.setText(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/input_GUNADI_form-control form-control-sm n_46c275'), 
    '33', FailureHandling.CONTINUE_ON_FAILURE)

WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/td'))

WebUI.comment('Add member Deleted')

WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/span_Rp_p-button-icon ri-team-line ng-star-_2dff8b_1'))

WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/span_Rp_p-button-icon ri-delete-bin-line ng_8b6a0c_1'))

WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/Input'))

WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/span_Rp_p-button-icon ri-delete-bin-line ng_8b6a0c_1_2'))

WebUI.verifyElementPresent(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/button_PROCCESS'), 
    0)

WebUI.comment('Pop up Save Draf')

not_run: WebUI.click(findTestObject('Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/btn_PROCCESS'))

WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/button_Cancel'))

WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/button_Draft'))

WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/button_Yes'))

WebUI.click(findTestObject('Object Repository/Page_SIPIT - Sistem Informasi Project/Menu Project/Project Incentive Request PIR/btnSummary-Checker/Page_SIPIT - Sistem Informasi ProjectInceti_174db9/btn_OK Draf'))

not_run: WebUI.closeBrowser()

WebUI.comment('Sheet Bonus Distribution - Technician')

''', 'Test Cases/TCManual - Project Incentive Request/5_Cheker/TCB.18.19.20_RoleChecker - PIR - Add employe', new TestCaseBinding('Test Cases/TCManual - Project Incentive Request/5_Cheker/TCB.18.19.20_RoleChecker - PIR - Add employe',[:]), FailureHandling.STOP_ON_FAILURE , false)
    
