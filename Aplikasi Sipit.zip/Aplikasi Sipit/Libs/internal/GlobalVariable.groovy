package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object sls
     
    /**
     * <p></p>
     */
    public static Object URL_WEB
     
    /**
     * <p></p>
     */
    public static Object pm
     
    /**
     * <p></p>
     */
    public static Object pwd
     
    /**
     * <p></p>
     */
    public static Object ach
     
    /**
     * <p></p>
     */
    public static Object f
     
    /**
     * <p></p>
     */
    public static Object h
     
    /**
     * <p></p>
     */
    public static Object c
     
    /**
     * <p></p>
     */
    public static Object N10
     
    /**
     * <p></p>
     */
    public static Object NPro
     
    /**
     * <p></p>
     */
    public static Object URL_WEB_PROD
     
    /**
     * <p></p>
     */
    public static Object test10
     
    /**
     * <p></p>
     */
    public static Object PName
     
    /**
     * <p></p>
     */
    public static Object CS
     
    /**
     * <p></p>
     */
    public static Object PAmount
     
    /**
     * <p></p>
     */
    public static Object PNumber
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += TestCaseMain.getParsedValues(RunConfiguration.getOverridingParameters(), selectedVariables)
    
            sls = selectedVariables['sls']
            URL_WEB = selectedVariables['URL_WEB']
            pm = selectedVariables['pm']
            pwd = selectedVariables['pwd']
            ach = selectedVariables['ach']
            f = selectedVariables['f']
            h = selectedVariables['h']
            c = selectedVariables['c']
            N10 = selectedVariables['N10']
            NPro = selectedVariables['NPro']
            URL_WEB_PROD = selectedVariables['URL_WEB_PROD']
            test10 = selectedVariables['test10']
            PName = selectedVariables['PName']
            CS = selectedVariables['CS']
            PAmount = selectedVariables['PAmount']
            PNumber = selectedVariables['PNumber']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
