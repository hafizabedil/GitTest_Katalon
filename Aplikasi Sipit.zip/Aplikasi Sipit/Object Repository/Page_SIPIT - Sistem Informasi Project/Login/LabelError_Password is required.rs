<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>LabelError_Password is required</name>
   <tag></tag>
   <elementGuidId>5f79069f-2f7f-46c2-ae33-9c5ba86bdf31</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Password'])[1]/following::span[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.invalid-feedback > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Password is required&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>ce0efcca-6130-4097-ad13-359788ad2ef2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Password is required</value>
      <webElementGuid>593ac143-93bb-4aa0-a75a-f47d3c8a82e6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-login[1]/div[@class=&quot;auth-page-wrapper auth-bg-cover py-5 d-flex justify-content-center align-items-center min-vh-100&quot;]/div[@class=&quot;auth-page-content overflow-hidden pt-lg-5&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;card overflow-hidden&quot;]/div[@class=&quot;row g-0&quot;]/div[@class=&quot;col-lg-4&quot;]/div[@class=&quot;p-lg-5 p-4&quot;]/div[@class=&quot;mt-4&quot;]/form[@class=&quot;ng-touched ng-dirty ng-invalid ng-submitted&quot;]/div[@class=&quot;mb-3&quot;]/div[@class=&quot;position-relative auth-pass-inputgroup mb-3&quot;]/div[@class=&quot;invalid-feedback&quot;]/span[1]</value>
      <webElementGuid>6a6ed8f2-bd6d-4e5b-a434-b8ea27fca3f4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Password'])[1]/following::span[1]</value>
      <webElementGuid>29ae40ef-4698-4a45-930f-d24a825130f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Username'])[1]/following::span[1]</value>
      <webElementGuid>0748515a-8ee6-4b1a-a72c-c34bdf59ac50</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Remember me'])[1]/preceding::span[1]</value>
      <webElementGuid>327066d8-d479-49d5-87b2-62a54987cd5c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign In'])[1]/preceding::span[1]</value>
      <webElementGuid>5a1b1e19-a31d-4522-97f3-6ffd46d2014d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Password is required']/parent::*</value>
      <webElementGuid>d6f39b2c-7beb-4725-8759-6a46a014fa10</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/div/span</value>
      <webElementGuid>20b2b170-39b3-4d02-abb8-853e37024ca2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Password is required' or . = 'Password is required')]</value>
      <webElementGuid>21d6c06d-4cf6-4089-8633-8fdcd18b1062</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
