<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Lebel_Welcome To SIPIT</name>
   <tag></tag>
   <elementGuidId>a4b565b2-ccc6-43df-96b2-d34f9bba0679</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h5.text-primary</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Slide 3 of 3'])[1]/following::h5[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Welcome To SIPIT!&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h5</value>
      <webElementGuid>50224e1b-172a-4b19-bae3-d26785c16270</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-primary</value>
      <webElementGuid>956017f7-a1e4-48ea-9e0c-a0f5ff940a30</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Welcome To SIPIT!</value>
      <webElementGuid>f5962d39-47d5-4173-a2a9-b2c3da6b5908</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-login[1]/div[@class=&quot;auth-page-wrapper auth-bg-cover py-5 d-flex justify-content-center align-items-center min-vh-100&quot;]/div[@class=&quot;auth-page-content overflow-hidden pt-lg-5&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;card overflow-hidden&quot;]/div[@class=&quot;row g-0&quot;]/div[@class=&quot;col-lg-4&quot;]/div[@class=&quot;p-lg-5 p-4&quot;]/div[1]/h5[@class=&quot;text-primary&quot;]</value>
      <webElementGuid>3d1a03be-b26a-4113-9499-8afb517fbb9c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Slide 3 of 3'])[1]/following::h5[1]</value>
      <webElementGuid>c0aedaa8-9510-461a-8369-946163c081ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Slide 2 of 3'])[1]/following::h5[1]</value>
      <webElementGuid>a46936b4-f116-4765-b974-dbc36f828d68</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Username'])[1]/preceding::h5[1]</value>
      <webElementGuid>c632d5c8-d746-467f-9d3b-dcf5e53444a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Password'])[1]/preceding::h5[1]</value>
      <webElementGuid>c6b25400-aaff-4364-8629-fc447ff6ae33</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Welcome To SIPIT!']/parent::*</value>
      <webElementGuid>5a997d59-b3e4-44b2-aecb-5a6db452771c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h5</value>
      <webElementGuid>78137563-0fdb-4d2c-9526-d2aa6ae9aa3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h5[(text() = 'Welcome To SIPIT!' or . = 'Welcome To SIPIT!')]</value>
      <webElementGuid>320e0ff2-868a-4f8b-a1c3-3db5e9fe5648</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
