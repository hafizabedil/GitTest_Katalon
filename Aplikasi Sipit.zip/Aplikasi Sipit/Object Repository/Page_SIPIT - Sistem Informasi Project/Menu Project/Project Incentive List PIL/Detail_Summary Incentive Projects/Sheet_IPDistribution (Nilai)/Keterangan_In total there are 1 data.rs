<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Keterangan_In total there are 1 data</name>
   <tag></tag>
   <elementGuidId>6caf1a70-f610-4b43-9be8-56bc3c9957b6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.p-d-flex.p-ai-center.p-jc-between</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='pn_id_2']/div[2]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;In total there are 1 data.&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>50cc7530-b8db-42b4-901f-3cd08d69af5f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>p-d-flex p-ai-center p-jc-between</value>
      <webElementGuid>2cb59f9d-3a2c-417c-a289-72adf44c9995</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> In total there are 1 data. </value>
      <webElementGuid>b36de1ed-fa15-4ca8-b1d4-ca5ca51e7308</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pn_id_2&quot;)/div[@class=&quot;p-datatable-footer&quot;]/div[@class=&quot;p-d-flex p-ai-center p-jc-between&quot;]</value>
      <webElementGuid>08093ba1-5554-4913-8b6a-6a0bca2e296b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='pn_id_2']/div[2]/div</value>
      <webElementGuid>79b2e4ea-dc81-4061-803d-15afd7977e58</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Showing 1 to 1 of 1 entries'])[1]/following::div[2]</value>
      <webElementGuid>1d39bcfd-08a6-4a81-b6ad-2a564bb603df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='HR'])[1]/following::div[3]</value>
      <webElementGuid>38f1234e-c5a6-4ab1-ae4b-3e59a99ca48c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Design &amp; Develop by PT. OGYA TEKNO NUSANTARA'])[1]/preceding::div[2]</value>
      <webElementGuid>d7d58d8b-a212-48ae-bf58-cee2a9a0103b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Loading...'])[2]/preceding::div[6]</value>
      <webElementGuid>c2401093-13cf-4c74-b2c9-e5ea6c63d201</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='In total there are 1 data.']/parent::*</value>
      <webElementGuid>aa78f93a-2c17-4126-9899-1107de37d58c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p-table/div/div[2]/div</value>
      <webElementGuid>35b17a41-c597-4abc-9e56-c64936cf2476</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = ' In total there are 1 data. ' or . = ' In total there are 1 data. ')]</value>
      <webElementGuid>07f436ab-0ec7-47ad-9531-3d6cc5b31be5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
