<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_Nama Customer</name>
   <tag></tag>
   <elementGuidId>20bc26da-d8ed-4a25-8fad-9659a7b4c1a4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(3) > td:nth-of-type(2)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='ngb-nav-2-panel']/table/tbody/tr[3]/td[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;PEMPROV DKI&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>600a4f7f-61f6-428a-bf1f-a9cf6c45720b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>PEMPROV DKI</value>
      <webElementGuid>f4fc8e2c-c4ea-4a3a-8998-6e93755ece9c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ngb-nav-2-panel&quot;)/table[@class=&quot;table&quot;]/tbody[1]/tr[3]/td[2]</value>
      <webElementGuid>2b3596d8-80eb-4925-a04d-ed6b2097e2e0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='ngb-nav-2-panel']/table/tbody/tr[3]/td[2]</value>
      <webElementGuid>0e9fdf20-9608-4d61-b1b5-42aabf9f6dd8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='End User'])[1]/following::td[1]</value>
      <webElementGuid>ceb167d9-58f5-4c4c-a4da-729b894259a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PROJECTTEST19031'])[1]/following::td[6]</value>
      <webElementGuid>f5f72fcd-8540-4d84-915a-033f65377dad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nilai Tagihan'])[1]/preceding::td[5]</value>
      <webElementGuid>01d3f0d6-6249-40ff-aff6-3399b8dcf351</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rp'])[1]/preceding::td[9]</value>
      <webElementGuid>1c34e705-23c3-4e0c-8f80-bad5076a98af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='PEMPROV DKI']/parent::*</value>
      <webElementGuid>6c0a21c0-3532-4d0e-bd0c-6995f4709c3f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[3]/td[2]</value>
      <webElementGuid>55ce55b4-b139-4719-953a-2f9d37e16a06</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'PEMPROV DKI' or . = 'PEMPROV DKI')]</value>
      <webElementGuid>aa25c187-e812-4025-abe2-b50bfffd653a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
