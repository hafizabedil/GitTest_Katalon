<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_Total Biaya</name>
   <tag></tag>
   <elementGuidId>2b754dd7-071e-41c8-9bc0-6e8a840dcaaf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>td.title.healthy</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='ngb-nav-2-panel']/table/tbody/tr[27]/td</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Total Biaya&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>881338fe-1e72-4b31-9a78-c2880822befe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>colspan</name>
      <type>Main</type>
      <value>4</value>
      <webElementGuid>33fdce84-e1cb-4d07-b8b6-04d81892a81e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>title healthy</value>
      <webElementGuid>a8f7f3d3-a247-452c-af0d-5f32ed6e19c6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-reflect-ng-class</name>
      <type>Main</type>
      <value>[object Object]</value>
      <webElementGuid>2285d647-5b0d-44fe-aaca-567e80225f1e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Total Biaya</value>
      <webElementGuid>4e2efb99-3892-4053-a6b7-e88c054bdb0c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ngb-nav-2-panel&quot;)/table[@class=&quot;table&quot;]/tbody[1]/tr[27]/td[@class=&quot;title healthy&quot;]</value>
      <webElementGuid>282dfbb6-9fd4-4313-a682-878c2553cbaa</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='ngb-nav-2-panel']/table/tbody/tr[27]/td</value>
      <webElementGuid>6548de56-af02-440a-88aa-92982c1c1769</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Summary'])[2]/following::td[7]</value>
      <webElementGuid>219f631e-5eaa-47bd-820c-f81a8da9cf2f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rp'])[16]/following::td[16]</value>
      <webElementGuid>331ec76b-6630-42ec-9ff0-9eca881f5d2d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rp'])[17]/preceding::td[1]</value>
      <webElementGuid>ec4ba7ef-f625-4a2e-a585-ea3ba47faead</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Margin Perusahaan'])[1]/preceding::td[3]</value>
      <webElementGuid>94c634fa-7780-4e8b-b3df-ed53a69272c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Total Biaya']/parent::*</value>
      <webElementGuid>6ec818cf-af12-4466-863d-600849790d56</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[27]/td</value>
      <webElementGuid>3b0296dc-8ff8-4b74-9c63-42c1268cc66f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = ' Total Biaya' or . = ' Total Biaya')]</value>
      <webElementGuid>791ca45c-17f9-4a93-be40-c853f8a947cf</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
