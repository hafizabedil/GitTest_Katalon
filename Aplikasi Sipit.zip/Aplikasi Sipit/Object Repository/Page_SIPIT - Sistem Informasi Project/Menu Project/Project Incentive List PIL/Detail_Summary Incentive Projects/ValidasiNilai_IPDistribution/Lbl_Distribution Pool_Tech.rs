<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Lbl_Distribution Pool_Tech</name>
   <tag></tag>
   <elementGuidId>aaa861a1-f3bf-41a9-aeeb-7956a212d3a7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(5) > td:nth-of-type(2)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='ngb-nav-3-panel']/div/div/ip-distribution-view-base/table/tbody/tr[5]/td[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Distribution Pool&quot;i] >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>b6e171fd-fb9f-4820-b717-876a701da94f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Distribution Pool</value>
      <webElementGuid>69e7e0ff-c8d5-4272-8141-02130210afb1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ngb-nav-3-panel&quot;)/div[@class=&quot;card&quot;]/div[@class=&quot;card-body&quot;]/ip-distribution-view-base[1]/table[@class=&quot;table&quot;]/tbody[1]/tr[5]/td[2]</value>
      <webElementGuid>469a8f04-dafe-4549-b543-939921b1e853</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='ngb-nav-3-panel']/div/div/ip-distribution-view-base/table/tbody/tr[5]/td[2]</value>
      <webElementGuid>d6887953-59e7-4d0a-aaa9-c9d5ddf52d23</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Technician'])[1]/following::td[1]</value>
      <webElementGuid>121861e3-a795-44ce-a5b6-df708c917e00</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rp'])[4]/following::td[9]</value>
      <webElementGuid>0ac308f2-e086-4c34-8aca-6d3f1860aadb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rp'])[5]/preceding::td[4]</value>
      <webElementGuid>a044c5d0-ca94-4766-848a-1b74cd0e5adb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[5]/td[2]</value>
      <webElementGuid>c166ac52-e958-4f28-9352-64ac91d9fa19</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'Distribution Pool' or . = 'Distribution Pool')]</value>
      <webElementGuid>59d1cbe4-5bd4-4b3a-bdf4-de630133a5c6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
