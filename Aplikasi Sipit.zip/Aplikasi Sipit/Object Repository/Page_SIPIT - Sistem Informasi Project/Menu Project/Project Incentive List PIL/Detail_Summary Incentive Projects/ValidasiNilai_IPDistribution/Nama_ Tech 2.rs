<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Nama_ Tech 2</name>
   <tag></tag>
   <elementGuidId>76781ed4-6e41-4799-a411-5251c50aefe0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(8) > td</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='ngb-nav-3-panel']/div/div/ip-distribution-view-base/table/tbody/tr[8]/td</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;AAD ALIYUDIN&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>dc4e980a-d46f-4e90-b03b-c3632b0c5428</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>AAD ALIYUDIN</value>
      <webElementGuid>1ff9b138-3838-401d-a342-d21baf881d3e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ngb-nav-3-panel&quot;)/div[@class=&quot;card&quot;]/div[@class=&quot;card-body&quot;]/ip-distribution-view-base[1]/table[@class=&quot;table&quot;]/tbody[1]/tr[8]/td[1]</value>
      <webElementGuid>6c4fef12-02d6-43dc-ba70-eb2d8e7dc7b9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='ngb-nav-3-panel']/div/div/ip-distribution-view-base/table/tbody/tr[8]/td</value>
      <webElementGuid>81b84483-7b3b-452c-8659-6bb45a09ce3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rp'])[6]/following::td[2]</value>
      <webElementGuid>20a9d65b-da11-456a-89d6-0e53708cbad6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='%'])[2]/following::td[4]</value>
      <webElementGuid>0a1ecedc-6606-417a-a888-5c08bb05d815</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='%'])[3]/preceding::td[2]</value>
      <webElementGuid>8737b82e-00c4-462c-97e9-175caa3e6aa1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rp'])[7]/preceding::td[4]</value>
      <webElementGuid>8c7fbae9-4c10-4373-9b16-707280c6f51a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='AAD ALIYUDIN']/parent::*</value>
      <webElementGuid>8cab8ef2-b23d-48c4-a2c1-d8a7871ec0ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[8]/td</value>
      <webElementGuid>45ac78f4-6d2b-47ea-a210-0cfc93e351b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'AAD ALIYUDIN' or . = 'AAD ALIYUDIN')]</value>
      <webElementGuid>7053a65d-e348-4489-9e79-20a6c8c2f8e1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
