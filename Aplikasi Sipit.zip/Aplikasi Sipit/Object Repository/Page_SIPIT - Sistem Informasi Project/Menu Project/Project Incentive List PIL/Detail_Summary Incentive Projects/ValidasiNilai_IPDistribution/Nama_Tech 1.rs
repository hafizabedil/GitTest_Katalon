<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Nama_Tech 1</name>
   <tag></tag>
   <elementGuidId>e136337e-78ef-460d-b8d6-a55c2821f3c3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(7) > td</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='ngb-nav-3-panel']/div/div/ip-distribution-view-base/table/tbody/tr[7]/td</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;AHMAD SANJANI&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>0a7c9970-5cab-4249-9da0-771037547d0a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>AHMAD SANJANI</value>
      <webElementGuid>59feb5d7-283b-45c6-b8b2-f38875d2d152</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ngb-nav-3-panel&quot;)/div[@class=&quot;card&quot;]/div[@class=&quot;card-body&quot;]/ip-distribution-view-base[1]/table[@class=&quot;table&quot;]/tbody[1]/tr[7]/td[1]</value>
      <webElementGuid>732c03a2-747b-4399-8c80-7bf2dcdb2c6f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='ngb-nav-3-panel']/div/div/ip-distribution-view-base/table/tbody/tr[7]/td</value>
      <webElementGuid>7ffe6a85-9780-48f3-8716-41481f8586c1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rp'])[5]/following::td[8]</value>
      <webElementGuid>c2ddc060-d9e0-439e-9d6f-a0ed2806f547</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Distribution Pool'])[1]/following::td[12]</value>
      <webElementGuid>76d90d93-07e8-44b4-a942-e512c76352e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='%'])[2]/preceding::td[2]</value>
      <webElementGuid>85efae78-8856-48af-a151-92f30be6f0fd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rp'])[6]/preceding::td[4]</value>
      <webElementGuid>c3f20d70-f4bd-4037-8e3e-7c434c3369fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='AHMAD SANJANI']/parent::*</value>
      <webElementGuid>17e6e457-c7a0-456c-941f-1795901e2b46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[7]/td</value>
      <webElementGuid>fce35ea1-273e-4bbc-b73f-c2d2718a67dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'AHMAD SANJANI' or . = 'AHMAD SANJANI')]</value>
      <webElementGuid>9959e051-0513-448b-abc5-24d6070147d9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
