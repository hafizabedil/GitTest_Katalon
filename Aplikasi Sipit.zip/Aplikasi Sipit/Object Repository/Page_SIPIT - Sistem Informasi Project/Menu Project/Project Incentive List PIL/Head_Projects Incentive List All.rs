<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Head_Projects Incentive List All</name>
   <tag></tag>
   <elementGuidId>41d3f481-977d-4b39-a573-eac06d57b8c5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='orderList']/div/div/div/h5</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h5.card-title.mb-0</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Projects Incentive List All&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h5</value>
      <webElementGuid>b39d19ec-585f-46ad-8cde-ab283b389fb0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>card-title mb-0</value>
      <webElementGuid>9ab4f697-e39b-472b-b378-6527d74ae4a5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Projects Incentive List All</value>
      <webElementGuid>cabc2215-894c-42eb-82ba-f6a0f690a370</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;orderList&quot;)/div[@class=&quot;card-header border-0&quot;]/div[@class=&quot;row align-items-cinput gy-3&quot;]/div[@class=&quot;col-sm&quot;]/h5[@class=&quot;card-title mb-0&quot;]</value>
      <webElementGuid>4f38001c-caa8-4150-b3c4-be335a61fc0c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='orderList']/div/div/div/h5</value>
      <webElementGuid>e8234715-d1b4-42f7-be17-f2a7491b843f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Projects'])[2]/following::h5[1]</value>
      <webElementGuid>a2738587-a6e3-4a10-9d5b-fcc446934692</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Apps'])[1]/following::h5[1]</value>
      <webElementGuid>585e7341-f463-46fc-a0fb-f1ec71edb9ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='List Status Incentive Projects'])[1]/preceding::h5[1]</value>
      <webElementGuid>7ab17935-4293-4d66-958b-085977c977db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Projects Incentive Paid'])[1]/preceding::h5[1]</value>
      <webElementGuid>941c643a-d97a-47fa-86f2-3611e58dd16e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Projects Incentive List All']/parent::*</value>
      <webElementGuid>aa53c099-4cb4-40cc-9c37-dd38ffc03218</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h5</value>
      <webElementGuid>321903af-c87d-4d3c-985c-8203252ab8aa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h5[(text() = 'Projects Incentive List All' or . = 'Projects Incentive List All')]</value>
      <webElementGuid>77f8edfb-cb57-4641-afc9-3e9369c0fb26</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
