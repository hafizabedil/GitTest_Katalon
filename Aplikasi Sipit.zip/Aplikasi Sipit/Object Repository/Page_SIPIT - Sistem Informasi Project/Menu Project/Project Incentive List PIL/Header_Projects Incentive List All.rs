<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Header_Projects Incentive List All</name>
   <tag></tag>
   <elementGuidId>ac5d0167-0374-46b1-a221-930dd7f0cda8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='orderList']/div/div/div/h5</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h5.card-title.mb-0</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Projects Incentive List All&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h5</value>
      <webElementGuid>42aa0046-8872-4de3-9afa-8d9a0801377b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>card-title mb-0</value>
      <webElementGuid>02200734-43ca-4db9-8348-eace5658d675</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Projects Incentive List All</value>
      <webElementGuid>e5be1984-c857-4512-bb5e-846811ebb865</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;orderList&quot;)/div[@class=&quot;card-header border-0&quot;]/div[@class=&quot;row align-items-cinput gy-3&quot;]/div[@class=&quot;col-sm&quot;]/h5[@class=&quot;card-title mb-0&quot;]</value>
      <webElementGuid>10204d57-23e7-407c-9816-29a72a370f33</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='orderList']/div/div/div/h5</value>
      <webElementGuid>4eb6c30d-9ae9-4e8f-b63c-37d1edc4535b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Projects'])[2]/following::h5[1]</value>
      <webElementGuid>6953e787-5b81-49a3-9aec-4e3951a5a5bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Apps'])[1]/following::h5[1]</value>
      <webElementGuid>5c5e9bf3-dcdc-4d03-b964-1be129bae6dc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='List Status Incentive Projects'])[1]/preceding::h5[1]</value>
      <webElementGuid>26b6ad4c-fe65-4cf4-bd38-db59e2a09807</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Projects Incentive Paid'])[1]/preceding::h5[1]</value>
      <webElementGuid>83b6d98e-9395-44b8-9cd1-65da1791c5d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Projects Incentive List All']/parent::*</value>
      <webElementGuid>c21e37ea-4d46-436c-92e3-f874324572a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h5</value>
      <webElementGuid>12bbcedf-c912-4893-9434-4c961455abfa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h5[(text() = 'Projects Incentive List All' or . = 'Projects Incentive List All')]</value>
      <webElementGuid>348a0a7e-3a19-4eeb-8e3c-ae210a2e232b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
