<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Table _Nama Project</name>
   <tag></tag>
   <elementGuidId>41fca3b6-eb03-4894-8922-5d9b8665bd73</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>td</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//table[@id='pn_id_1-table']/tbody/tr/td</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;PROJECT BCA TEST&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>eec758fe-fbb8-49e4-9c9b-bcdd32859149</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> PROJECT BCA TEST </value>
      <webElementGuid>19e84c72-6fbb-4194-83b3-cb9461dfa12a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pn_id_1-table&quot;)/tbody[@class=&quot;p-element p-datatable-tbody&quot;]/tr[1]/td[1]</value>
      <webElementGuid>9ddb778f-923e-4cae-ada5-2ec77a0d595a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//table[@id='pn_id_1-table']/tbody/tr/td</value>
      <webElementGuid>14b0dacf-7b7a-4eec-9bb2-e89e48c54460</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='End'])[2]/following::td[1]</value>
      <webElementGuid>7f31d57b-206e-463d-8297-2b600944fedb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Start'])[2]/following::td[1]</value>
      <webElementGuid>f35f4aa5-a298-4b65-91ea-e2e7ebfddf81</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TESTER'])[1]/preceding::td[1]</value>
      <webElementGuid>39826bd9-12e5-4ff6-9d8f-116e394b3819</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New Project'])[2]/preceding::td[7]</value>
      <webElementGuid>f70c579a-c24b-4a54-a3ab-4e97b1b1550d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='PROJECT BCA TEST']/parent::*</value>
      <webElementGuid>c5c3841d-a044-47c6-985e-2c98ca73dc96</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td</value>
      <webElementGuid>c59a0b2e-aeab-4ad8-ad31-58313afef246</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = ' PROJECT BCA TEST ' or . = ' PROJECT BCA TEST ')]</value>
      <webElementGuid>7a365ba3-4121-4478-b56d-cfea1ecc7e47</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
