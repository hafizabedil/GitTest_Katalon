<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Data_Customer</name>
   <tag></tag>
   <elementGuidId>4a0805e4-9fe2-43f3-a6b0-5387451a55ac</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='End'])[2]/following::td[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>td:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;TESTING ALL&quot;i] >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>a66d2209-f355-40db-bd5b-e7d7cc664aa6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> TESTING ALL </value>
      <webElementGuid>cca963bf-d111-4513-af3d-63f764278a5f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pn_id_1-table&quot;)/tbody[@class=&quot;p-element p-datatable-tbody&quot;]/tr[1]/td[2]</value>
      <webElementGuid>d9dc95cb-169b-4ecb-bf62-144909666194</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//table[@id='pn_id_1-table']/tbody/tr/td[2]</value>
      <webElementGuid>6d6c60b9-ae7a-4026-b699-14d22d81410f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TEST MINGGU'])[1]/following::td[1]</value>
      <webElementGuid>a6c3ec53-e091-4bd9-8d03-ea00de21f2a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='End'])[2]/following::td[2]</value>
      <webElementGuid>90c256c7-7ceb-45d9-95c9-bab3626a9c7b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New Project'])[2]/preceding::td[6]</value>
      <webElementGuid>f58368a6-e97b-462a-8584-270b855a4862</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='waiting'])[1]/preceding::td[7]</value>
      <webElementGuid>87e67e93-9aae-4005-ba6c-1b91ff7b1cae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='TESTING ALL']/parent::*</value>
      <webElementGuid>5b5b47ff-4ba4-4fb0-bd3b-a530fc1961e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[2]</value>
      <webElementGuid>156f05b6-82eb-4f82-8158-444d8aee8cf1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = ' TESTING ALL ' or . = ' TESTING ALL ')]</value>
      <webElementGuid>184608cc-62bc-402d-957c-5ccaad8aec4f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
