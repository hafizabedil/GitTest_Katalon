<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>HeaderOption_Welcome To SIPITSistem Informasi</name>
   <tag></tag>
   <elementGuidId>dec6ce2b-23f5-461e-aa1d-fb8a9ee6f3ce</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Slide 3 of 3'])[1]/following::div[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-lg-4 > div.p-lg-5.p-4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Welcome To SIPIT!Sistem Informasi Project Incentive TerpaduUsernamePasswordRemem&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>7c2fa7a1-57c9-4487-8de4-faa4bd7c05ce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>p-lg-5 p-4</value>
      <webElementGuid>52e053e5-1d04-4253-a5e7-d36d19cc7a0c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Welcome To SIPIT!Sistem Informasi Project Incentive TerpaduUsernamePasswordRemember meSign In</value>
      <webElementGuid>01443f6c-0c29-4937-8b52-a3545a83d998</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-login[1]/div[@class=&quot;auth-page-wrapper auth-bg-cover py-5 d-flex justify-content-center align-items-center min-vh-100&quot;]/div[@class=&quot;auth-page-content overflow-hidden pt-lg-5&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;card overflow-hidden&quot;]/div[@class=&quot;row g-0&quot;]/div[@class=&quot;col-lg-4&quot;]/div[@class=&quot;p-lg-5 p-4&quot;]</value>
      <webElementGuid>03b10e56-9f74-4aac-a4cd-7e96ccd3c1e0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Slide 3 of 3'])[1]/following::div[4]</value>
      <webElementGuid>54b88c67-8660-46dd-863a-74d215079292</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Slide 2 of 3'])[1]/following::div[7]</value>
      <webElementGuid>76ca2608-2060-4f73-8a7a-fe655cdeca81</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[2]/div</value>
      <webElementGuid>f1dfafbc-5c55-4b11-8901-04ee1566ae96</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Welcome To SIPIT!Sistem Informasi Project Incentive TerpaduUsernamePasswordRemember meSign In' or . = 'Welcome To SIPIT!Sistem Informasi Project Incentive TerpaduUsernamePasswordRemember meSign In')]</value>
      <webElementGuid>e9e3ba2c-4442-4be4-9981-98cafd82c64c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
