<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Welcome To SIPITSistem Informasi Projec_7cf03a</name>
   <tag></tag>
   <elementGuidId>7d6174fc-a6ec-47a2-bb5d-953b301619e9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Slide 3 of 3'])[1]/following::div[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-lg-4 > div.p-lg-5.p-4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Welcome To SIPIT!Sistem Informasi Project Incentive TerpaduUsernamePasswordRemem&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>0647fe4b-0951-46e5-8747-365461f4b496</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>p-lg-5 p-4</value>
      <webElementGuid>3b846c2a-f7c1-4545-bc55-1bf606132b47</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Welcome To SIPIT!Sistem Informasi Project Incentive TerpaduUsernamePasswordRemember meSign In</value>
      <webElementGuid>aeffba42-3308-4cd2-815f-9411bc7cbc99</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-login[1]/div[@class=&quot;auth-page-wrapper auth-bg-cover py-5 d-flex justify-content-center align-items-center min-vh-100&quot;]/div[@class=&quot;auth-page-content overflow-hidden pt-lg-5&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;card overflow-hidden&quot;]/div[@class=&quot;row g-0&quot;]/div[@class=&quot;col-lg-4&quot;]/div[@class=&quot;p-lg-5 p-4&quot;]</value>
      <webElementGuid>50443c8a-7e05-4442-9969-06511931a72f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Slide 3 of 3'])[1]/following::div[4]</value>
      <webElementGuid>ded936a4-8c4e-45b4-a28d-95da53c43ea6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Slide 2 of 3'])[1]/following::div[7]</value>
      <webElementGuid>dd25a195-9e60-4c76-9c40-ee6c13347918</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[2]/div</value>
      <webElementGuid>f736a633-63c9-4c8f-85bb-fdbc10dedb10</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Welcome To SIPIT!Sistem Informasi Project Incentive TerpaduUsernamePasswordRemember meSign In' or . = 'Welcome To SIPIT!Sistem Informasi Project Incentive TerpaduUsernamePasswordRemember meSign In')]</value>
      <webElementGuid>8aeb492e-673d-405b-82ca-d441419a602c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
