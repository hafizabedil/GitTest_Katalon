<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Select_Staff Sales</name>
   <tag></tag>
   <elementGuidId>2ae1a79a-5d7c-4642-9739-a6fc7d303044</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='projectSummary']/div[2]/div/table/tbody/tr[2]/td[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr.ng-star-inserted > td:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>td >> internal:has-text=&quot;PilihManagerAdmin SalesStaff SalesPre-Sales&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>240d66d5-176b-49c2-96a8-da3834f00d0d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>PilihManagerAdmin SalesStaff SalesPre-Sales</value>
      <webElementGuid>d2e36e84-d4ad-4d55-be82-9333d04b67cb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;projectSummary&quot;)/div[@class=&quot;card-body&quot;]/div[@class=&quot;row&quot;]/table[@class=&quot;table&quot;]/tbody[1]/tr[@class=&quot;ng-star-inserted&quot;]/td[2]</value>
      <webElementGuid>b8d2ab31-18f4-4202-9a1d-86ba7052230f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='projectSummary']/div[2]/div/table/tbody/tr[2]/td[2]</value>
      <webElementGuid>437355be-08d1-4955-8b4d-57df365670df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='JIMMY SALINDEHO'])[1]/following::td[1]</value>
      <webElementGuid>4cd6e147-50e7-4927-bb63-3b8dfefe5e35</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rp'])[2]/following::td[5]</value>
      <webElementGuid>c6348fdb-7eca-4e11-b2ff-b7d5c604c52c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='%'])[1]/preceding::td[1]</value>
      <webElementGuid>12d7328b-f3e2-455e-b125-472e8326ef75</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rp'])[3]/preceding::td[3]</value>
      <webElementGuid>02f50535-8cd8-474a-8904-dab109627bcb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[2]/td[2]</value>
      <webElementGuid>98e96970-617a-485f-8730-f521ada52357</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'PilihManagerAdmin SalesStaff SalesPre-Sales' or . = 'PilihManagerAdmin SalesStaff SalesPre-Sales')]</value>
      <webElementGuid>2c757693-0df1-43b1-a36a-957d5bfdd132</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
