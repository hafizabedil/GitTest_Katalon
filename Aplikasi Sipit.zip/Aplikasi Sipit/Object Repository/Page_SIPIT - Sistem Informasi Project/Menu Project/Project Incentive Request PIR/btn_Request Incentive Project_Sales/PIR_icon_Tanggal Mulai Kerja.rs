<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PIR_icon_Tanggal Mulai Kerja</name>
   <tag></tag>
   <elementGuidId>63224c20-e40b-40d6-8670-5216276552b5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Tanggal Mulai Kerja'])[1]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div >> internal:has-text=/^Tanggal Mulai KerjaTanggal Selesai Kerja$/ >> span >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>363cdd3f-8a9d-4467-bb0c-6f4beba3563c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>input-group-text</value>
      <webElementGuid>21e8254c-2d40-4488-9dab-0db5e00d36ab</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/ngb-modal-window[@class=&quot;d-block modal fade show&quot;]/div[@class=&quot;modal-dialog modal-dialog-centered modal-md&quot;]/div[@class=&quot;modal-content&quot;]/form[@class=&quot;tablelist-form ng-invalid ng-touched ng-dirty&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;row gy-4 mb-3&quot;]/div[@class=&quot;col-md-6&quot;]/div[@class=&quot;flex flex-auto flex-wrap&quot;]/div[@class=&quot;input-group&quot;]/span[@class=&quot;input-group-text&quot;]</value>
      <webElementGuid>b6715e54-d357-4886-921f-c5d7acd0e007</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tanggal Mulai Kerja'])[1]/following::span[1]</value>
      <webElementGuid>486663b2-48dd-405a-a948-a68b7c6c6312</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tanggal Selesai Kontrak'])[1]/following::span[2]</value>
      <webElementGuid>744fb85b-d7ea-4b1d-aa4f-c3e44535a850</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tanggal Selesai Kerja'])[1]/preceding::span[1]</value>
      <webElementGuid>c8299148-c5ab-458b-b768-7b51d0806e0f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Close'])[1]/preceding::span[2]</value>
      <webElementGuid>382552f5-9221-4fc1-93a3-297a011afb73</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div/span</value>
      <webElementGuid>6b943f90-d420-404d-a2e3-e1aaa85992bb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
