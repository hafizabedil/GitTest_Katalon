<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Select_ACHMADI MAULIA NUGRAHA</name>
   <tag></tag>
   <elementGuidId>fc8ac22e-432e-43ef-ae0a-5aa93abcacf7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#pn_id_16_0 > span.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Project Manager'])[1]/following::span[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;ACHMADI MAULIA NUGRAHA&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>f10aac89-4178-45c8-90f2-bfb842d2ea64</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-star-inserted</value>
      <webElementGuid>94f0b3af-998f-4fd1-b78f-843d890492d6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>ACHMADI MAULIA NUGRAHA</value>
      <webElementGuid>5ec10950-1abf-4571-a3b7-9c1ee5747464</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pn_id_16_0&quot;)/span[@class=&quot;ng-star-inserted&quot;]</value>
      <webElementGuid>0f6e27aa-042a-4c09-b3df-cfb02f54e725</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='pn_id_16_0']/span</value>
      <webElementGuid>bcc2932f-8dbb-41f5-923f-54ca8949406e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Project Manager'])[1]/following::span[3]</value>
      <webElementGuid>18654a43-af67-4a12-b982-e57709cca791</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Company On Project'])[1]/following::span[3]</value>
      <webElementGuid>0695e65b-a15c-4d16-b22b-83aba866e573</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tanggal Mulai Kontrak'])[1]/preceding::span[2]</value>
      <webElementGuid>40b51865-91e8-473e-92b8-b2b1bb2e4e5f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tanggal Selesai Kontrak'])[1]/preceding::span[3]</value>
      <webElementGuid>0b7009c9-f974-4021-b384-58f3cd77a166</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='ACHMADI MAULIA NUGRAHA']/parent::*</value>
      <webElementGuid>d882d5f1-2555-4f69-b926-ef6bc5ac8381</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p-dropdownitem/li/span</value>
      <webElementGuid>57a75465-4a1d-42fc-bc55-e28ce8ff12b5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'ACHMADI MAULIA NUGRAHA' or . = 'ACHMADI MAULIA NUGRAHA')]</value>
      <webElementGuid>8d5de9ab-05b1-4320-beae-8caa74c099e9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
