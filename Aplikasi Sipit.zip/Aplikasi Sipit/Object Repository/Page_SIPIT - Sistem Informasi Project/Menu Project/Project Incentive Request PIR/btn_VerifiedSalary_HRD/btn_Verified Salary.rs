<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Verified Salary</name>
   <tag></tag>
   <elementGuidId>f7532427-fc4a-44e3-ab7b-ccd5c5a13882</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='waiting'])[1]/following::span[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.p-button-label.ng-star-inserted</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=row[name=&quot;PROJECTTEST10031 CLIENT 1,000,000,001 01/03/2025 01/03/2025 01/03/2025 31/03/2025 New Project waiting  Verified Salary&quot;i] >> internal:role=button</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>4cce049e-60a6-4bd4-9fce-23434e31d673</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>p-button-label ng-star-inserted</value>
      <webElementGuid>c67c8c3a-3e0e-42eb-ba65-1c85e82318ee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>618f7107-6a9e-4382-acef-e99f3f62d5b8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-pc-section</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>7b41adea-4d05-47b4-a0e5-636d3fdf2418</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Verified Salary</value>
      <webElementGuid>d3aa37b7-9a50-4405-be64-60511bb1ee53</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pn_id_2-table&quot;)/tbody[@class=&quot;p-element p-datatable-tbody&quot;]/tr[@class=&quot;ng-star-inserted&quot;]/td[10]/div[@class=&quot;grid-container ng-star-inserted&quot;]/div[@class=&quot;grid-item&quot;]/p-button[@class=&quot;p-element&quot;]/button[@class=&quot;p-ripple p-element p-button p-component p-button-sm p-button-success&quot;]/span[@class=&quot;p-button-label ng-star-inserted&quot;]</value>
      <webElementGuid>3d708b39-e124-4981-8182-f21e588c5326</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//table[@id='pn_id_2-table']/tbody/tr/td[10]/div/div/p-button/button/span[2]</value>
      <webElementGuid>dda1d777-6081-4d29-a54e-2349522cc545</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='waiting'])[1]/following::span[2]</value>
      <webElementGuid>9af8001c-5bff-4a23-bf66-dffd0e346ada</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New Project'])[2]/following::span[4]</value>
      <webElementGuid>1b1d72b4-dc48-4808-aaca-35cdbeb819c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PROJECTTEST1003'])[1]/preceding::span[1]</value>
      <webElementGuid>897baf2c-f554-43ce-b459-cbc5ae877894</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CLIENT'])[2]/preceding::span[1]</value>
      <webElementGuid>8e4b35af-5f17-4b49-b062-759356c71c6c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Verified Salary']/parent::*</value>
      <webElementGuid>9bb3b777-7add-451e-a451-7c1f8431a7f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/span[2]</value>
      <webElementGuid>c72d3957-8050-4022-81c2-425ba74f2120</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Verified Salary' or . = 'Verified Salary')]</value>
      <webElementGuid>7447b0e0-fff2-44b8-a038-fa59c9eaf24d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
