<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PopUp_Login Failed</name>
   <tag></tag>
   <elementGuidId>390a266a-4fc7-4759-8c01-2adfcd3fbe5b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>/html/body/app-root/app-login/app-toasts/ngb-toast/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>class=&quot;toast-body&quot;</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
