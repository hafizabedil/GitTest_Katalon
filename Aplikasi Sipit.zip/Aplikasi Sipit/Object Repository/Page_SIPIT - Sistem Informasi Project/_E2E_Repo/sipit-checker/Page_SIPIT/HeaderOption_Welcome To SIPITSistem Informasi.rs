<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>HeaderOption_Welcome To SIPITSistem Informasi</name>
   <tag></tag>
   <elementGuidId>9cbed9eb-5260-456f-b008-f11e58dacc93</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Slide 3 of 3'])[1]/following::div[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-lg-4 > div.p-lg-5.p-4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Welcome To SIPIT!Sistem Informasi Project Incentive TerpaduUsernamePasswordRemem&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>3ef893ed-04ad-4427-8ec4-6914a82149a2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>p-lg-5 p-4</value>
      <webElementGuid>f03ad93c-df22-4c1c-b33d-5d541822cd93</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Welcome To SIPIT!Sistem Informasi Project Incentive TerpaduUsernamePasswordRemember meSign In</value>
      <webElementGuid>7c5eae5a-02e7-4fea-8325-6b4c4c63dd59</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-login[1]/div[@class=&quot;auth-page-wrapper auth-bg-cover py-5 d-flex justify-content-center align-items-center min-vh-100&quot;]/div[@class=&quot;auth-page-content overflow-hidden pt-lg-5&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;card overflow-hidden&quot;]/div[@class=&quot;row g-0&quot;]/div[@class=&quot;col-lg-4&quot;]/div[@class=&quot;p-lg-5 p-4&quot;]</value>
      <webElementGuid>3eaa900f-ca74-41c3-aba2-21abf52d5d30</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Slide 3 of 3'])[1]/following::div[4]</value>
      <webElementGuid>c63e0582-75e5-4e40-8d27-eff4a600207c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Slide 2 of 3'])[1]/following::div[7]</value>
      <webElementGuid>f5964e36-da68-49be-9faa-58a2ae938bf0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[2]/div</value>
      <webElementGuid>b6a27e3c-c388-4d84-a49e-57de9f583ed7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Welcome To SIPIT!Sistem Informasi Project Incentive TerpaduUsernamePasswordRemember meSign In' or . = 'Welcome To SIPIT!Sistem Informasi Project Incentive TerpaduUsernamePasswordRemember meSign In')]</value>
      <webElementGuid>f191add7-b628-4080-89a3-eb0c2c69e994</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
