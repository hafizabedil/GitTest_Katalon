<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Select_JIMMY SALINDEHO</name>
   <tag></tag>
   <elementGuidId>0e1efee2-7061-4601-99e1-b2e1a48eb178</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#pn_id_6_0 > span.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Design &amp; Develop by PT. OGYA TEKNO NUSANTARA'])[1]/following::span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;JIMMY SALINDEHO&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>1ab54d23-2523-431d-aa19-f48817325e37</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-star-inserted</value>
      <webElementGuid>d8d94658-9260-4bc6-b8b4-42e8c2a6e2b5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>JIMMY SALINDEHO</value>
      <webElementGuid>dcf0cbe5-da32-4e70-b4d5-150c595efc07</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pn_id_6_0&quot;)/span[@class=&quot;ng-star-inserted&quot;]</value>
      <webElementGuid>603ba2e2-8bf4-40be-be3b-5be8ec58ed86</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='pn_id_6_0']/span</value>
      <webElementGuid>4f27dc28-67b8-45e2-8242-8cfdd684ea46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Design &amp; Develop by PT. OGYA TEKNO NUSANTARA'])[1]/following::span[2]</value>
      <webElementGuid>f86cc35f-214c-42d3-8ae0-085a291c0e62</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='JIMMY SALINDEHO']/parent::*</value>
      <webElementGuid>7c527d7c-768e-45af-b324-1b1cfa178781</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p-dropdownitem/li/span</value>
      <webElementGuid>1d3e65d9-1e68-41b7-9615-e0f778ccd967</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'JIMMY SALINDEHO' or . = 'JIMMY SALINDEHO')]</value>
      <webElementGuid>0cdd53f3-7b06-4902-adba-3d85f563223d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
