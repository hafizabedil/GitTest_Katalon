<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Select_Staff Sales</name>
   <tag></tag>
   <elementGuidId>4f6bad53-ebe2-4f2b-a6a4-e96ac2770ac4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='projectSummary']/div[2]/div/table/tbody/tr[2]/td[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr.ng-star-inserted > td:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>td >> internal:has-text=&quot;PilihManagerAdmin SalesStaff SalesPre-Sales&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>3926073c-1803-4b1f-b538-96b158f507f7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>PilihManagerAdmin SalesStaff SalesPre-Sales</value>
      <webElementGuid>127b122a-990c-4424-95f4-15eb3ae4b2b9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;projectSummary&quot;)/div[@class=&quot;card-body&quot;]/div[@class=&quot;row&quot;]/table[@class=&quot;table&quot;]/tbody[1]/tr[@class=&quot;ng-star-inserted&quot;]/td[2]</value>
      <webElementGuid>210a0411-8115-4644-9d5f-b728d91c20b4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='projectSummary']/div[2]/div/table/tbody/tr[2]/td[2]</value>
      <webElementGuid>79ab99cf-ae63-4a59-ad86-9bb3e718fcb6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='JIMMY SALINDEHO'])[1]/following::td[1]</value>
      <webElementGuid>0879048c-e036-45bd-87b4-e0269504daec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rp'])[2]/following::td[5]</value>
      <webElementGuid>3315d47e-f6b6-4c45-be1e-329957fb15a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='%'])[1]/preceding::td[1]</value>
      <webElementGuid>ff7c789c-37e7-4112-a609-b22bf945ef5a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rp'])[3]/preceding::td[3]</value>
      <webElementGuid>a6b9e409-6d4f-4151-9f0f-8c53ac3c3b87</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[2]/td[2]</value>
      <webElementGuid>0218fd65-65eb-4e95-9366-582df684fc60</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'PilihManagerAdmin SalesStaff SalesPre-Sales' or . = 'PilihManagerAdmin SalesStaff SalesPre-Sales')]</value>
      <webElementGuid>781d0820-f0fa-4e21-971e-f00bc56941e0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
